from torch import nn
import torch.nn


class DecoderOnly(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.seq_length = 110

        self.lin_inp = nn.Linear(config['D_INPUT'], config['D_MODEL'])

        encoder_layer = nn.TransformerEncoderLayer(d_model=config['D_MODEL'], nhead=config["N_HEAD"], batch_first=True, dropout=config['DROPOUT'])
        transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=config['NUM_LAYERS'])

        self.lin_op = nn.Linear(config['D_MODEL'], config['D_OUTPUT'])
        
        self.network = transformer_encoder

    def forward(self, inp):

        reshaped_inp = inp.transpose(1, 2).flatten(start_dim=2)
        inp1 = self.lin_inp(reshaped_inp)
        
        causal_mask = nn.Transformer.generate_square_subsequent_mask(self.seq_length).to(self.config['DEVICE'])
        output = self.network(inp1, mask=causal_mask)
        
        op = self.lin_op(output)
        reshaped_op = op.reshape((op.shape[0], op.shape[1], 50, 9)).transpose(1, 2)
        # breakpoint()

        return reshaped_op 

    def generate(self, inp, steps=60):
        reshaped_inp = inp.transpose(1, 2).flatten(start_dim=2) # (examples, agents, timesteps, attrs) -> (examples, timesteps, agents * attrs)
        inp1 = self.lin_inp(reshaped_inp)
        org_steps = inp1.shape[1]
        
        input_cast = torch.zeros((inp1.shape[0], org_steps + steps, inp1.shape[2])).to(self.config['DEVICE'])
        input_cast[:, :org_steps, :] = inp1
        
        causal_mask = nn.Transformer.generate_square_subsequent_mask(self.seq_length).to(self.config['DEVICE'])

        for step in range(steps):
            step_output = self.network(input_cast, mask=causal_mask)
            input_cast[:, org_steps + step , :] = step_output[:, org_steps + step - 1, :]
        
        op = self.lin_op(input_cast)
        reshaped_op = op.reshape((op.shape[0], op.shape[1], 50, 9)).transpose(1, 2)

        return reshaped_op
